<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * File response question definition class.
 *
 * @package    qtype
 * @subpackage fileresponse
 * @copyright  2012 Luca Bösch luca.boesch@bfh.ch
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();

/**
 * Represents an fileresponse question.
 *
 * @copyright  2012 Luca Bösch luca.boesch@bfh.ch
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class qtype_fileresponse_question extends question_with_responses {
    public $responseformat;
    public $responsefieldlines;
    public $attachments;
    public $forcedownload;
    public $graderinfo;
    public $graderinfoformat;

    public function make_behaviour(question_attempt $qa, $preferredbehaviour) {
        question_engine::load_behaviour_class('manualgraded');
        return new qbehaviour_manualgraded($qa, $preferredbehaviour);
    }

    /**
     * @param moodle_page the page we are outputting to.
     * @return qtype_fileresponse_format_renderer_base the response-format-specific renderer.
     */
    public function get_format_renderer(moodle_page $page) {
        return $page->get_renderer('qtype_fileresponse', 'format_' . $this->responseformat);
    }

    public function get_expected_data() {
        /* fileresponse only accepts 'formatplain' as format */
        if ($this->responseformat == 'editorfilepicker') {
            $expecteddata = array('answer' => question_attempt::PARAM_CLEANHTML_FILES);
        } else {
            $expecteddata = array('answer' => PARAM_CLEANHTML);
        }
        $expecteddata['answerformat'] = PARAM_FORMAT;
        if ($this->attachments != 0) {
            $expecteddata['attachments'] = question_attempt::PARAM_FILES;
        }
        return $expecteddata;
    }

    public function summarise_response(array $response) {
        /* It would be nice to have the answer text but a list of the files' uploaded names as well */
        if (isset($response['answer'])) {
            $formatoptions = new stdClass();
            $formatoptions->para = false;
            return html_to_text(format_text($response['answer'], FORMAT_HTML, $formatoptions), 0, false);
        } else {
            return null;
        }
    }

    public function get_correct_response() {
        return null;
    }

    public function get_question_file_saver_value(array $response) {
    /* returns the questions fileuploader's question_file_saver value */
        foreach ($response as $name => $value) {
            if ($value instanceof question_file_saver){
            $question_file_saver_value = (string) $value;
            }
        }
        return $question_file_saver_value;
    }

    public function get_question_attemptstepid(array $response, $question_file_saver_value) {
    /* should return the questions's attempt step id. does not work reliably */
        global $CFG, $DB;

        $attemptstepparams = array('value' => $question_file_saver_value);
        $attemptstepsql = "SELECT attemptstepid FROM {question_attempt_step_data} WHERE name = 'attachments' AND value = :value";
        return $DB->get_field_sql($attemptstepsql, $attemptstepparams);

    }

    public function get_question_userid(array $response, $question_attemptstepid) {
    /* should return the userid of the user which fills in this questions's attempt step. does not work reliably, since the parameter $question_attemptstepid often comes in as NULL */
        global $CFG, $DB;

        $useridparams = array('value' => $question_attemptstepid);
        $useridsql = "SELECT userid FROM {question_attempt_steps} WHERE id = :value";
        return $DB->get_field_sql($useridsql, $useridparams);

//        $attemptstepparams = array('value' => $question_file_saver_value);
//        $directsql = "SELECT userid FROM {question_attempt_steps} WHERE id = (SELECT attemptstepid FROM {question_attempt_step_data} WHERE name = 'attachments' AND value = :value";
//        return $DB->get_field_sql($directsql, $attemptstepparams);

    }

    /* SELECT * FROM mdl_context WHERE contextlevel = '70' AND instanceid = '2'    gibt 21 zurück */
    /* contextlevel 70 enspricht MODULE, vgl http://moodle.org/mod/forum/discuss.php?d=202515*/
    /* SELECT * FROM mdl_files WHERE contextid = '21' AND component = 'question' AND filearea = 'response_attachments' AND itemid = '112'  ORDER BY id     gibt die fileliste zurück */

    public function amount_uploaded_files(array $response) {
    /* should return the amount of already uploaded files. but, from this point, there is no possibility though to access the question_attempt_step and its fileuploader. */
        global $CFG, $DB;

//        $question_file_saver_value = $this->get_question_file_saver_value($response);
//        $question_attemptstepid = $this->get_question_attemptstepid($response, $this->get_question_file_saver_value($response));
        $userid = $this->get_question_userid($response, $this->get_question_attemptstepid($response, $this->get_question_file_saver_value($response)));
        $fs = get_file_storage();
        $usercontext = get_context_instance(CONTEXT_USER, $userid);

        $alreadysavedfiles = $fs->get_area_files($usercontext->id, 'user', 'draft', false, 'id', false);
    }

    public function is_complete_response(array $response) {
        print_r($response);
        /* fileupload question type is always complete (i.e. ready for grading) */
        /* always returns true, since from this point, there is no possibility though to the question_attempt_step and its fileuploader */
        return true;
    }

    public function is_same_response(array $prevresponse, array $newresponse) {
    /* fileupload question responses are never the same */
    /* should return true when there is an answer, and the same answer in the comment field (or both answers are empty and the uploaded files are identical */
    /* always returns false, since from this point, there is no possibility though to the question_attempt_step and its fileuploader */
       return false;
    }

    public function check_file_access($qa, $options, $component, $filearea, $args, $forcedownload) {
        if ($component == 'question' && $filearea == 'response_attachments') {
            // Response attachments visible if the question has them.
            return $this->attachments != 0;

        } else if ($component == 'question' && $filearea == 'response_answer') {
            // Response attachments visible if the question has them.
            return $this->responseformat === 'editorfilepicker';

        } else if ($component == 'qtype_fileresponse' && $filearea == 'graderinfo') {
            return $options->manualcomment;

        } else {
            return parent::check_file_access($qa, $options, $component,
                    $filearea, $args, $forcedownload);
        }
    }

    public function classify_response(array $response) {
        return array();
    }
}
